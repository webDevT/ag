$(function(){

    $('.menu-btn').click(function(){
        $(this).toggleClass('active');
        $('.header__right').toggleClass('active');
    })

    $('.destination-item__plus').click(function(){
        $(this).parent().parent().find('.destination-item__content').slideToggle();
        $(this).parent().toggleClass('active');
    })

    $('.destination-item__plus').click(function(){
        $(this).parent().parent().find('.destination-item__content').slideToggle();
        $(this).parent().toggleClass('active');
    })

    $('.itinerary-item .destination-item__header').click(function(){
        $(this).parent().find('.destination-item__content').slideToggle();
        $(this).toggleClass('active');
    })





});

// ------start sticky header------

$(window).scroll(function() {
    if ($(this).scrollTop() > 1){
    $('.header').addClass("sticky");
    }
    else{
    $('.header').removeClass("sticky");
    }
    });
    
//-------end sticky header---

//start slider
$(function(){
$('.slider').slick({
    slidesToShow: 1,
    prevArrow: $('.prev'),
    nextArrow: $('.next'),
    autoplay: true,
    autoplaySpeed: 4000,
    pauseOnHover: false
});

$('.multu-slider').slick({
    slidesToShow: 3,
    nextArrow: $('.multu-next'),
    prevArrow: $('.multu-prev'),
    responsive: [
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 1,
          }
        }
    ]
});
});
//end slider
if($(window).width() < 992) {

        $('.menu > ul > li > a').on('click', function(event) {
          event.preventDefault(); 
          $(this).siblings('.sub-menu').toggleClass('active');
         $('.sub-menu-item').toggleClass('active');
        });
  
      
}